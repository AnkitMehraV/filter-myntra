const bbk_electronics = [
    {
        compant_name: "oneplus",
        model: "nord",
        price: 29000,
        color: "cloud blue"
    },
    {
        compant_name: "oneplus",
        model: "nord",
        price: 29000,
        color: "cherry red"
    },
    {
        compant_name: "oneplus",
        model: "nord 2",
        price: 31000,
        color: "cloud blue"
    },
    {
        compant_name: "oneplus",
        model: "nord 2",
        price: 31000,
        color: "cherry red"
    },

    {
        compant_name: "oneplus",
        model: "10",
        price: 59000,
        color: "cloud blue"
    },
    {
        compant_name: "oneplus",
        model: "10",
        price: 59000,
        color: "cherry red"
    },
    {
        compant_name: "oneplus",
        model: "10",
        price: 59000,
        color: "glossy green"
    },
    {
        compant_name: "oneplus",
        model: "10 pro",
        price: 61000,
        color: "cloud blue"
    },
    {
        compant_name: "oneplus",
        model: "nord",
        price: 29000,
        color: "cloud blue"
    }, {
        compant_name: "oneplus",
        model: "nord",
        price: 29000,
        color: "cloud blue"
    }
]

function keypressfilter() {
    let tbl = `<table border='1' width='600' <tr><th>COMPANY NAME</th><th>MODEL</th><th>PRICE</th><hr>COLOR</hr></tr>`
    let searchValue = document.getElementById("search").value
    let filterdata = bbk_electronics.filter(function (getvalue) {
        if(searchValue==getvalue.compant_name.startsWith(searchValue)){
            return console.log("ye item hai")
        }


    })
    filterdata.forEach(function (x) {
        tbl += `<tr><th>${x.compant_name}</th><th>${x.model}</th><th>${x.price}</th><th>${x.color}</th></tr>`


    });
    

}